# Relax AI Android starter
This is an early Android WebView demo shell. It is not a production AI app.
The demo does not connect to a real AI backend, live news, financial data, or user accounts.
Build with Android Gradle Plugin 8.7.3 and Gradle 8.9, JDK 17, Android SDK 35.
